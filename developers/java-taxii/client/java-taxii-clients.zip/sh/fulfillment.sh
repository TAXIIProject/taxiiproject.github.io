#!
java -cp ../java-taxii-clients-all.jar org.mitre.taxii.client.example.FulfillmentClient $*
